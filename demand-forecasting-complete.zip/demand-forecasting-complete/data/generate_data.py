"""Generate synthetic daily sales data with seasonality and noise."""
import pandas as pd
import numpy as np
from pathlib import Path

out = Path(__file__).resolve().parent / "historical_sales.csv"

np.random.seed(42)
days = 365*10  # 10 years daily
date_range = pd.date_range(end=pd.Timestamp.today(), periods=days, freq='D')

# seasonal pattern + trend + noise
seasonality = 10 + 5 * np.sin(2 * np.pi * date_range.dayofyear / 365)
trend = np.linspace(0, 20, len(date_range))
noise = np.random.normal(0, 3, len(date_range))

sales = (50 + seasonality + trend + noise).round().astype(int)
df = pd.DataFrame({
    "date": date_range,
    "store_id": 1,
    "product_id": 101,
    "sales": sales
})
df.to_csv(out, index=False)
print(f"Saved {len(df)} rows to {out}")
