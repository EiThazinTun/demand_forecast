from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

with DAG(
    dag_id='demand_forecast_pipeline',
    start_date=datetime(2024,1,1),
    schedule_interval='@daily',
    catchup=False,
    default_args={'retries':1, 'retry_delay': timedelta(minutes=5)}
) as dag:

    validate_data = BashOperator(
        task_id='validate_data',
        bash_command='[ -f /opt/airflow/data/historical_sales.csv ] && echo "ok" || echo "missing"'
    )

    train_model = BashOperator(
        task_id='train_model',
        bash_command='python /opt/airflow/ml_pipeline/train.py'
    )

    generate_predictions = BashOperator(
        task_id='generate_predictions',
        bash_command='python /opt/airflow/ml_pipeline/predict.py'
    )

    notify_completion = BashOperator(
        task_id='notify_completion',
        bash_command='echo "Pipeline complete"'
    )

    validate_data >> train_model >> generate_predictions >> notify_completion
