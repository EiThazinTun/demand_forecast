# Simple connection check script for Kafka and SQL Server
from confluent_kafka import Producer
import pyodbc

print('Checking Kafka producer...')
p = Producer({'bootstrap.servers': 'localhost:9092'})
print('Kafka producer created (will error if broker not reachable).')

conn_str = (
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost,1433;"
    "UID=sa;"
    "PWD=StrongPass!2025;"
    "Encrypt=yes;"
    "TrustServerCertificate=yes;"
)

try:
    conn = pyodbc.connect(conn_str, autocommit=True, timeout=5)
    print('SQL Server connected')
except Exception as e:
    print('SQL Server connection error:', e)
