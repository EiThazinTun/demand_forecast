-- Optional: run this in SQL Server to create database and tables in advance
CREATE DATABASE DemandForecasting;
GO
USE DemandForecasting;
GO
CREATE TABLE raw_sales (
  id INT IDENTITY(1,1) PRIMARY KEY,
  event_time DATETIME,
  store_id INT,
  product_id INT,
  sales INT
);
GO
