"""Simple Kafka producer that reads CSV and publishes JSON messages to topic 'sales_data'."""
import argparse, json, time
import pandas as pd
from confluent_kafka import Producer

def delivery_report(err, msg):
    if err is not None:
        print(f"Delivery failed: {err}")
    else:
        print(f"Produced to {msg.topic()} [{msg.partition()}] at offset {msg.offset()}")

def main(csv_file, bootstrap='localhost:9092', topic='sales_data', delay=0.01):
    p = Producer({'bootstrap.servers': bootstrap})
    df = pd.read_csv(csv_file, parse_dates=['date'])
    for i, row in df.iterrows():
        payload = row.to_dict()
        payload['date'] = str(payload['date'])
        p.produce(topic, json.dumps(payload).encode('utf-8'), callback=delivery_report)
        p.poll(0)
        time.sleep(delay)
    p.flush()
    print('Finished producing')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--csv', dest='csv', required=True)
    parser.add_argument('--bootstrap', default='localhost:9092')
    parser.add_argument('--topic', default='sales_data')
    args = parser.parse_args()
    main(args.csv, args.bootstrap, args.topic)
