"""Kafka consumer that writes incoming messages to MS SQL Server raw_sales table."""
import json, time
from confluent_kafka import Consumer
import pyodbc
from urllib.parse import quote_plus

KAFKA_TOPIC = 'sales_data'
BOOTSTRAP = 'localhost:9092'
GROUP = 'demand_forecast_consumers'

def ensure_db(conn):
    c = conn.cursor()
    c.execute("IF DB_ID('DemandForecasting') IS NULL CREATE DATABASE DemandForecasting;")
    conn.commit()

def ensure_table(conn):
    c = conn.cursor()
    c.execute("USE DemandForecasting; IF OBJECT_ID('raw_sales','U') IS NULL CREATE TABLE raw_sales (id INT IDENTITY(1,1) PRIMARY KEY, event_time DATETIME, store_id INT, product_id INT, sales INT);")
    conn.commit()

def connect_sql():
    # Adjust driver/server if needed
    conn_str = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=localhost,1433;"
        "UID=sa;PWD=mF421707"
    )
    conn = pyodbc.connect(conn_str, autocommit=True)
    return conn

def main():
    c = Consumer({
        'bootstrap.servers': BOOTSTRAP,
        'group.id': GROUP,
        'auto.offset.reset': 'earliest'
    })
    c.subscribe([KAFKA_TOPIC])
    conn = None
    print('Consumer started, connecting to SQL Server...')
    while True:
        msg = c.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            print('Error: ', msg.error())
            continue
        data = json.loads(msg.value().decode('utf-8'))
        if conn is None:
            try:
                conn = connect_sql()
                ensure_db(conn)
                ensure_table(conn)
            except Exception as e:
                print('DB connection error:', e)
                time.sleep(5)
                conn = None
                continue
        try:
            cursor = conn.cursor()
            cursor.execute("USE DemandForecasting; INSERT INTO raw_sales (event_time, store_id, product_id, sales) VALUES (?,?,?,?);",
                           data.get('date'), int(data.get('store_id',1)), int(data.get('product_id',0)), int(data.get('sales',0)))
            conn.commit()
            print('Inserted:', data.get('date'))
        except Exception as e:
            print('Insert error:', e)

if __name__ == '__main__':
    main()
