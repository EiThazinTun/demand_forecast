# Demand Forecasting — Ready-to-use Project

This archive contains a full example project for an end-to-end demand forecasting pipeline using:
- Apache Kafka (Zookeeper + Kafka)
- Microsoft SQL Server (mssql)
- Apache Airflow (webserver + scheduler)
- Python scripts for data generation, Kafka producer & consumer
- A skeleton ML pipeline (feature engineering / training / save model)

## Quick start (local)
1. Make sure Docker Desktop is running.
2. From project root:
   ```bash
   docker-compose up -d
   ```
3. Wait ~1-2 minutes for services to start.
4. Create a Python virtualenv and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate   # or venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```
5. Generate sample data:
   ```bash
   python data/generate_data.py
   ```
   This creates `data/historical_sales.csv`.

6. Start the Kafka producer in one terminal:
   ```bash
   python kafka/producer.py --csv data/historical_sales.csv
   ```

7. Start the Kafka consumer in another terminal:
   ```bash
   python kafka/consumer.py
   ```

8. Check SQL Server at `localhost:1433` (sa/mF421707). The consumer will create the `DemandForecasting` database and `raw_sales` table when it runs.

9. Airflow web UI: http://localhost:8080 (may require further Airflow initialization if using real image).

## What is included
- `docker-compose.yml` — containers for Kafka, Zookeeper, MSSQL, Postgres, Airflow
- `data/` — data generator and sample CSV
- `kafka/` — producer & consumer scripts
- `ml_pipeline/` — feature engineering, training & predict skeleton
- `airflow/dags/` — example DAG that ties the pieces together
- `requirements.txt` — Python dependencies
- `scripts/` — helper SQL initialization (optional)

## Notes & troubleshooting
- Running the whole stack requires Docker and enough memory.
- The provided Airflow image uses LocalExecutor for simplicity; in production configure appropriately.
- The Kafka Python scripts use `confluent_kafka` — if you prefer `kafka-python` feel free to swap.

If you want, I can:
- tailor the Docker Compose to use Confluent Platform with KRaft instead of Zookeeper,
- add unit tests and CI,
- create a VS Code devcontainer,
- or generate a PowerPoint report.

Enjoy — the zip is prepared for download in this conversation.
