# Minimal ODBC test to connect to SQL Server
import pyodbc
try:
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 18 for SQL Server};"
        "SERVER=localhost,1433;"
        "UID=sa;"
        "PWD=StrongPass!2025;"
        "Encrypt=no;",   # <- IMPORTANT when connecting locally
        timeout=5
    )
    cur = conn.cursor()
    cur.execute("SELECT 1")
    print('ODBC connection successful, SELECT 1 ->', cur.fetchone())
except Exception as e:
    print('ODBC error:', e)

