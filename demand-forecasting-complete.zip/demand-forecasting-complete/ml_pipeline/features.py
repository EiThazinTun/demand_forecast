import pandas as pd

def create_features(df):
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date')
    df['month'] = df['date'].dt.month
    df['day_of_week'] = df['date'].dt.dayofweek
    df['is_weekend'] = df['day_of_week'].isin([5,6]).astype(int)
    df['lag_1'] = df['sales'].shift(1).fillna(method='bfill')
    df['lag_7'] = df['sales'].shift(7).fillna(method='bfill')
    df['rolling_mean_7'] = df['sales'].rolling(7, min_periods=1).mean()
    df = df.dropna()
    return df
