"""Train a RandomForest model on historical_sales.csv and save model.joblib"""
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from joblib import dump
from ml_pipeline.features import create_features

def main(csv_path='data/historical_sales.csv', model_out='ml_pipeline/model.joblib'):
    df = pd.read_csv(csv_path, parse_dates=['date'])
    df_features = create_features(df)
    X = df_features[['month','day_of_week','is_weekend','lag_1','lag_7','rolling_mean_7']]
    y = df_features['sales']
    model = RandomForestRegressor(n_estimators=50, random_state=42)
    model.fit(X, y)
    dump(model, model_out)
    print('Saved model to', model_out)

if __name__ == '__main__':
    main()
