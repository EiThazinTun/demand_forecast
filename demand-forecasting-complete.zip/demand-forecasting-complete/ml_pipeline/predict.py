import pandas as pd
from joblib import load
from ml_pipeline.features import create_features

def predict(csv_path='data/historical_sales.csv', model_path='ml_pipeline/model.joblib', out='ml_pipeline/forecasts.csv'):
    df = pd.read_csv(csv_path, parse_dates=['date'])
    df_features = create_features(df)
    X = df_features[['month','day_of_week','is_weekend','lag_1','lag_7','rolling_mean_7']]
    model = load(model_path)
    preds = model.predict(X)
    df_features['forecast'] = preds
    df_features.to_csv(out, index=False)
    print('Wrote forecasts to', out)

if __name__ == '__main__':
    predict()
